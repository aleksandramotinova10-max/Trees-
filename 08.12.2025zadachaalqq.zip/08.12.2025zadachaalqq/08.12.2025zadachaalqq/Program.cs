﻿namespace _08._12._2025zadachaalqq
{
    using System;
    using System.Text;
    using System.Collections.Generic;

    class Program
    {
        static void Main(string[] args)
        {
            // Създаване на дървото
            Node siteTree = new Node("Начало")
            {
                Children = new List<Node>
            {
                new Node("За нас")
                {
                    Children =
                    {
                        new Node("Екип"),
                        new Node("История")
                    }
                },
                new Node("Услуги")
                {
                    Children =
                    {
                        new Node("Дизайн"),
                        new Node("Разработка"),
                        new Node("Цени")
                    }
                },
                new Node("Контакти")
                {
                    Children =
                    {
                        new Node("Локация"),
                        new Node("Форма за контакт")
                    }
                }
            }
            };

            // Генериране на менюто
            string htmlMenu = GenerateMenu(siteTree);

            // Печат
            Console.WriteLine("Генерирано HTML меню:");
            Console.WriteLine(htmlMenu);
        }

        // DFS метод за генериране на HTML списъци
        public static string GenerateMenu(Node node)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("<ul>");

            foreach (var child in node.Children)
            {
                sb.Append("<li>");
                sb.Append(child.Title);

                if (child.Children.Count > 0)
                {
                    sb.Append(GenerateMenu(child)); // DFS рекурсия
                }

                sb.Append("</li>");
            }

            sb.Append("</ul>");
            return sb.ToString();
        }
    }









}
