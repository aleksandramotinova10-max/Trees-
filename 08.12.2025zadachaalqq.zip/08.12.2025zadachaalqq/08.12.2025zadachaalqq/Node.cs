﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _08._12._2025zadachaalqq
{
    using System.Collections.Generic;

    public class Node
    {
        public string Title { get; set; }
        public List<Node> Children { get; set; }

        public Node(string title)
        {
            Title = title;
            Children = new List<Node>();
        }
    }





}
